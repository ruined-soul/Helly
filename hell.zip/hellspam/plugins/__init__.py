from hellspam import *
from hellspam.helpers import *
from hellspam.config import Config
