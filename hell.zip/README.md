<p align="center"><a href="https://telegram.dog/HELL_X_EMPIRE"><img src="https://te.legra.ph/file/130297165b2c77f5f09b4.jpg"></a></p>

# HELL SPAM BOT 😈

# Features 📝
- 5 Token Clients.
- Fastest Speed depend upon the Server.
- 24x7 Support from the Team.
- Everytime a New Update is done whenever needed.

# Requirements 🗝️

- API ID and Hash from [Telegram Web](https://my.telegram.org).
- 5 Bot Token from [BotFather](https://telegram.dog/botfather).
- Other Vars are **Optional**.

# Hosting 🔥

**•• Deploy to Heroku ••**

<h4> The most easiest way to host...</h4>

[![Deploy To Heroku](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy) 

**•• Deploy with Telegram Bot ••**

<h4> Deploy in Telegram Bot... </h4>

<p align="left"><a href="https://telegram.dog/XTZ_HerokuBot"><img src="https://img.shields.io/badge/Deploy%20Via%20Telegram-blue?style=for-the-badge&logo=telegram" width="200""/</a>  </p>

# Support 🧑‍💻

<p align="left"><a href="https://telegram.dog/HellSpamBot"><img src="https://img.shields.io/badge/JOIN%20UPDATE%20CHANNEL-red?style=for-the-badge&logo=telegram" width="200""/</a>  </p>
<p align="left"><a href="https://t.me/HellSpam_SupportChat"><img src="https://img.shields.io/badge/JOIN%20SUPPORT%20CHAT-yellow?style=for-the-badge&logo=telegram" width="200""/</a>  </p>

# Credits ♈

- [Akhil](https://GitHub.com/akhilprs) for writing codes and maintaining it.
- [Himanshu](https://github.com/H1M4N5HU0P) for his Mafia Spam Bot.

-------------------------

Made with Love >\

<p align="left"><a href="https://t.me/THE_TARGARYENS_EMPIRE"><img src="https://img.shields.io/badge/THE%20TARAGARYENS%20EMPIRE-blue?style=for-the-badge&logo=telegram" width="350""/</a>  </p>

